
/**
 * Get the number.
 * @return {number} The number.
 */
export function yo() {
    const a = 1;
    const b = a + a;
    42
}
