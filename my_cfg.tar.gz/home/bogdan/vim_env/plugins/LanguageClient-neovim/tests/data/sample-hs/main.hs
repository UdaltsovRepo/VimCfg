main :: IO()

main = putStrLn "hello"
