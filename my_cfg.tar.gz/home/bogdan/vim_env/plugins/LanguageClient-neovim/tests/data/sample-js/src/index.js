import {yo} from './libs';

/**
 * Get the number
 * @return {number} The number.
 */
function greet() {
    42
}

function main() {
    const a = 1;
    console.log(greet());
    // place holder for didChange test.
}

// place holder for didChange test.

function ref_in_main() {
    yo() + 1
}
