class A {
    missingThis: number;
    constructor() {
        missingThis = 33;
    }
}

const a = new A();
